# Fruits detection > 2025-08-13 9:29pm
https://universe.roboflow.com/shahds-workspace/fruits-detection-aphar

Provided by a Roboflow user
License: CC BY 4.0

